# Publicación de demostración en Render

1. Crear un repositorio privado en GitHub y subir el CONTENIDO de esta carpeta a la raíz del repositorio.
2. En Render seleccionar New > Blueprint, conectar el repositorio y confirmar render.yaml.
3. Configurar DEMO_PASSWORD con una contraseña única y fuerte. SECRET_KEY se genera automáticamente.
4. Esperar la compilación y abrir la URL que Render entregue.
5. Ingresar con admin, inspector o convivencia y la contraseña configurada.

ADVERTENCIA: Solo datos ficticios. Las cuentas de prueba tienen la misma contraseña. La base SQLite en el almacenamiento efímero de Render puede perderse al reiniciar o redesplegar. No activar notificaciones a personas reales. No utilizar como sistema institucional. No existe integración operativa con Appoderado ni IA generativa.

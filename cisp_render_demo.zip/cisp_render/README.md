# CISP Asistencia Inteligente v2

Prototipo educativo de aplicación web responsive con Flask y SQLite. **Solo usar con datos ficticios en equipo local**. No apto para producción ni para datos reales de menores sin evaluación de seguridad, privacidad y normativa chilena.

## Instalación

1. Python 3.10 o superior.
2. `pip install -r requirements.txt`
3. En Linux/macOS: `export DEMO_MODE=1` o Windows PowerShell: `$env:DEMO_MODE='1'`
4. `python app.py`
5. Abrir http://127.0.0.1:5000

Usuarios de demostración: `admin`, `inspector`, `convivencia`. Contraseña inicial de demostración para los tres: `Cambiar123!`. No usar esa contraseña fuera de un entorno de prueba. La base se crea al ejecutar la app.

## Funciones

* Inicio de sesión con hash de contraseñas y permisos por rol.
* Alta de estudiantes, registro de atrasos y revisión de justificaciones.
* Enlaces de respuesta con token aleatorio almacenado como hash, vencimiento de 48 horas y uso único.
* Registro de auditoría y estado de notificaciones.
* Análisis de recurrencia mediante reglas transparentes.
* Interfaz adaptable a teléfonos y computadores.
* En modo demo, enlace de justificación visible en mensaje de confirmación.

## Correo SMTP opcional

Configurar `SMTP_HOST`, `SMTP_PORT` (587), `SMTP_USER`, `SMTP_PASSWORD` y `SMTP_FROM`. Para una URL pública correcta detrás de proxy configurar infraestructura HTTPS y host verificado. En modo local, el correo incluirá un enlace localhost, que no sirve para apoderados externos.

## Appoderado

El adaptador `notify_appoderado` es un marcador de integración: **no envía notificaciones**. Requiere documentación oficial de API, credenciales institucionales, permisos y acuerdo con el proveedor. No se simula una conexión real.

## Antes de uso real

Agregar aprovisionamiento seguro de usuarios y apoderados, segundo factor o controles equivalentes, limitación de intentos, verificación de identidad del apoderado (el enlace por correo por sí solo no es suficiente), políticas de retención y borrado, gestión de consentimientos o base jurídica, respaldos cifrados, monitoreo, HTTPS, servidor WSGI, sesiones centralizadas, pruebas de autorización y revisión de cumplimiento de la Ley 19.628 y normativa aplicable. La clave de sesión debe ser persistente y secreta (`SECRET_KEY`). No activar `DEMO_MODE` en producción. La app no integra un LLM real y no debe enviar datos de menores a un proveedor de IA sin evaluación formal.

"""CISP v2: prototipo educativo. No desplegar con datos reales sin revisión de seguridad."""
import os, sqlite3, secrets, hashlib, smtplib, ssl, json, urllib.request
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from functools import wraps
from flask import Flask, request, session, redirect, url_for, render_template, flash, abort, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix

BASE=os.path.dirname(__file__)
app=Flask(__name__)
app.secret_key=os.environ.get('SECRET_KEY',secrets.token_hex(32))
app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Lax',SESSION_COOKIE_SECURE=os.getenv('COOKIE_SECURE')=='1',MAX_CONTENT_LENGTH=32*1024)
DB=os.getenv('DB_PATH',os.path.join(BASE,'cisp.db'))
ROLES=('admin','inspectoria','convivencia','apoderado')

def db():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');return c

def init():
 with db() as c:
  c.executescript('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL,student_id INTEGER);
 CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY,name TEXT NOT NULL,course TEXT NOT NULL,guardian_email TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS delays(id INTEGER PRIMARY KEY,student_id INTEGER NOT NULL REFERENCES students(id),arrived_at TEXT NOT NULL,reason TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'Pendiente',justification TEXT NOT NULL DEFAULT '',created_by INTEGER REFERENCES users(id),created_at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS links(id INTEGER PRIMARY KEY,delay_id INTEGER NOT NULL REFERENCES delays(id),token_hash TEXT UNIQUE NOT NULL,expires_at TEXT NOT NULL,used_at TEXT);
 CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,actor TEXT NOT NULL,action TEXT NOT NULL,record_id INTEGER,at TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY,delay_id INTEGER REFERENCES delays(id),channel TEXT NOT NULL,status TEXT NOT NULL,detail TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL);''')

def now():return datetime.now(timezone.utc)
def iso(dt=None):return (dt or now()).isoformat(timespec='seconds')
def audit(c,action,record_id=None):c.execute('INSERT INTO audit(actor,action,record_id,at) VALUES(?,?,?,?)',(str(session.get('uid','public')),action,record_id,iso()))
def tokenhash(token):return hashlib.sha256(token.encode()).hexdigest()
def csrf():
 if 'csrf' not in session:session['csrf']=secrets.token_urlsafe(24)
 return session['csrf']
app.jinja_env.globals['csrf_token']=csrf
@app.before_request
def protect():
 if request.method in ('POST','PUT','PATCH','DELETE'):
  if not secrets.compare_digest(request.form.get('_csrf','') or request.headers.get('X-CSRF-Token',''),csrf()):abort(400,'Token de formulario inválido')
@app.after_request
def headers(response):
 response.headers['X-Content-Type-Options']='nosniff';response.headers['X-Frame-Options']='DENY';response.headers['Referrer-Policy']='no-referrer';response.headers['Content-Security-Policy']="default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; form-action 'self'; base-uri 'self'; frame-ancestors 'none'"
 response.headers['Cache-Control']='no-store';return response

def login_required(*roles):
 def dec(fn):
  @wraps(fn)
  def wrapper(*args,**kwargs):
   if not session.get('uid'):return redirect(url_for('login'))
   if roles and session.get('role') not in roles:abort(403)
   return fn(*args,**kwargs)
  return wrapper
 return dec

def notify_email(address,student,course,arrived,link):
 host=os.getenv('SMTP_HOST');sender=os.getenv('SMTP_FROM');user=os.getenv('SMTP_USER');password=os.getenv('SMTP_PASSWORD')
 if not all((host,sender,user,password)):return 'No configurado'
 msg=EmailMessage();msg['From']=sender;msg['To']=address;msg['Subject']='CISP: registro de atraso'
 msg.set_content(f'Se registró un atraso de {student}, curso {course}, a las {arrived}.\nPara justificarlo ingrese al enlace seguro: {link}\nLa puntualidad favorece el aprendizaje desde el inicio de la clase. Si necesita apoyo, comuníquese con Inspectoría.\nEste enlace vence en 48 horas y solo admite una respuesta.')
 try:
  with smtplib.SMTP(host,int(os.getenv('SMTP_PORT','587')),timeout=10) as s:s.starttls(context=ssl.create_default_context());s.login(user,password);s.send_message(msg)
  return 'Enviado'
 except Exception:return 'Error de envío (revisar servidor)'

def notify_appoderado(student_id,delay_id):
 # Adaptador intencionalmente deshabilitado: requiere contrato y API oficial del proveedor.
 return 'Pendiente de integración oficial'

@app.route('/login',methods=['GET','POST'])
def login():
 if request.method=='POST':
  username=request.form.get('username','')[:100];password=request.form.get('password','')
  with db() as c:u=c.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone()
  if u and check_password_hash(u['password'],password):
   session.clear();session.update(uid=u['id'],role=u['role'],username=u['username']);csrf();return redirect(url_for('home'))
  flash('Credenciales incorrectas')
 return render_template('login.html')
@app.post('/logout')
def logout():session.clear();return redirect(url_for('login'))
@app.get('/')
@login_required()
def home():
 with db() as c:
  if session['role']=='apoderado':
   rows=c.execute('SELECT d.*,s.name,s.course FROM delays d JOIN students s ON s.id=d.student_id JOIN users u ON u.student_id=s.id WHERE u.id=? ORDER BY d.id DESC',(session['uid'],)).fetchall()
   return render_template('guardian.html',rows=rows)
  rows=c.execute('SELECT d.*,s.name,s.course FROM delays d JOIN students s ON s.id=d.student_id ORDER BY d.id DESC LIMIT 200').fetchall()
  students=c.execute('SELECT id,name,course FROM students ORDER BY course,name').fetchall()
  counts=c.execute('SELECT status,COUNT(*) n FROM delays GROUP BY status').fetchall()
  flagged=c.execute("SELECT s.name,s.course,COUNT(*) n FROM delays d JOIN students s ON s.id=d.student_id WHERE d.arrived_at>=? GROUP BY s.id HAVING COUNT(*)>=3 ORDER BY n DESC",((now()-timedelta(days=30)).date().isoformat(),)).fetchall()
  return render_template('dashboard.html',rows=rows,students=students,counts=counts,flagged=flagged)
@app.post('/students')
@login_required('admin','inspectoria')
def student_add():
 name=request.form.get('name','').strip()[:120];course=request.form.get('course','').strip()[:30];email=request.form.get('email','').strip()[:200]
 if not name or not course or '@' not in email:abort(400)
 with db() as c:
  cur=c.execute('INSERT INTO students(name,course,guardian_email) VALUES(?,?,?)',(name,course,email));audit(c,'student_created',cur.lastrowid)
 flash('Estudiante agregado');return redirect(url_for('home'))
@app.post('/delays')
@login_required('admin','inspectoria')
def delay_add():
 try:sid=int(request.form.get('student_id',''));arrived=datetime.fromisoformat(request.form.get('arrived_at',''))
 except (ValueError,TypeError):abort(400)
 if not 2020<=arrived.year<=2100:abort(400)
 reason=request.form.get('reason','').strip()[:500];token=secrets.token_urlsafe(32)
 with db() as c:
  s=c.execute('SELECT * FROM students WHERE id=?',(sid,)).fetchone()
  if not s:abort(404)
  cur=c.execute('INSERT INTO delays(student_id,arrived_at,reason,created_by,created_at) VALUES(?,?,?,?,?)',(sid,arrived.isoformat(timespec='minutes'),reason,session['uid'],iso()));did=cur.lastrowid
  c.execute('INSERT INTO links(delay_id,token_hash,expires_at) VALUES(?,?,?)',(did,tokenhash(token),iso(now()+timedelta(hours=48))))
  audit(c,'delay_created',did)
  link=url_for('justify',token=token,_external=True)
  mail=notify_email(s['guardian_email'],s['name'],s['course'],arrived.isoformat(timespec='minutes'),link)
  appstatus=notify_appoderado(sid,did)
  for channel,status in [('email',mail),('appoderado',appstatus)]:c.execute('INSERT INTO notifications(delay_id,channel,status,created_at) VALUES(?,?,?,?)',(did,channel,status,iso()))
 flash('Atraso registrado. Correo: '+mail+'. Appoderado: '+appstatus+'.')
 # Mostrar enlace solo para pruebas, nunca en registros ni informes.
 if os.getenv('DEMO_MODE')=='1':flash('Enlace de prueba: '+link)
 return redirect(url_for('home'))
@app.route('/justificar/<token>',methods=['GET','POST'])
def justify(token):
 if len(token)>100:abort(404)
 with db() as c:
  x=c.execute('SELECT l.*,d.arrived_at,d.status,s.name,s.course FROM links l JOIN delays d ON d.id=l.delay_id JOIN students s ON s.id=d.student_id WHERE l.token_hash=?',(tokenhash(token),)).fetchone()
  if not x or x['used_at'] or datetime.fromisoformat(x['expires_at'])<now():abort(404,'Enlace inválido o vencido')
  if request.method=='POST':
   note=request.form.get('justification','').strip()
   if not 5<=len(note)<=1500:abort(400,'Ingrese una justificación de 5 a 1500 caracteres')
   c.execute("UPDATE delays SET justification=?,status='En revisión' WHERE id=? AND status='Pendiente'",(note,x['delay_id']))
   c.execute('UPDATE links SET used_at=? WHERE id=?',(iso(),x['id']));audit(c,'justification_submitted',x['delay_id'])
   return render_template('thanks.html')
  return render_template('justify.html',x=x)
@app.post('/delays/<int:did>/review')
@login_required('admin','inspectoria','convivencia')
def review(did):
 status=request.form.get('status','')
 if status not in ('Justificado','No justificado','En seguimiento'):abort(400)
 with db() as c:
  if not c.execute('SELECT 1 FROM delays WHERE id=?',(did,)).fetchone():abort(404)
  c.execute('UPDATE delays SET status=? WHERE id=?',(status,did));audit(c,'review_'+status,did)
 flash('Estado actualizado');return redirect(url_for('home'))
@app.get('/analisis')
@login_required('admin','inspectoria','convivencia')
def analysis():
 with db() as c:
  rows=c.execute('SELECT s.course,COUNT(*) n FROM delays d JOIN students s ON s.id=d.student_id GROUP BY s.course ORDER BY n DESC').fetchall()
  frequent=c.execute('SELECT s.name,s.course,COUNT(*) n FROM delays d JOIN students s ON s.id=d.student_id WHERE d.arrived_at>=? GROUP BY s.id HAVING COUNT(*)>=3 ORDER BY n DESC',((now()-timedelta(days=30)).date().isoformat(),)).fetchall()
  pending=c.execute("SELECT COUNT(*) n FROM delays WHERE status='Pendiente'").fetchone()['n']
 return render_template('analysis.html',courses=rows,frequent=frequent,pending=pending)
@app.get('/health')
def health():return jsonify(status='ok')

def initialize_for_demo():
 init()
 if os.getenv('DEMO_MODE')=='1' and os.getenv('DEMO_PASSWORD'):
  with db() as c:
   if not c.execute('SELECT 1 FROM users').fetchone():
    for name,role in [('admin','admin'),('inspector','inspectoria'),('convivencia','convivencia')]:
     c.execute('INSERT INTO users(username,password,role) VALUES(?,?,?)',(name,generate_password_hash(os.environ['DEMO_PASSWORD']),role))
    print('Usuarios de demostración creados.')

if __name__=='__main__':
 initialize_for_demo()
 app.run(host='127.0.0.1',port=int(os.getenv('PORT','5000')),debug=False)

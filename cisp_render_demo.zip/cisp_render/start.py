from app import app, initialize_for_demo
initialize_for_demo()
